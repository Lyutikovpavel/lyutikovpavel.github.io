//
//  TimerViewController.swift
//  InsTrend
//
//  Created by mac on 03.03.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TimerViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
