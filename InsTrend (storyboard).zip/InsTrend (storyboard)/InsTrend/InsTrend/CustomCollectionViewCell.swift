//
//  CustomCollectionViewCell.swift
//  InsTrend
//
//  Created by mac on 07.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var imageFull: UIImageView!
    @IBOutlet weak var lblAutFull: UILabel!
    @IBOutlet weak var lblIstFull: UILabel!
    

    @IBOutlet weak var imageSrView: UIImageView!
    @IBOutlet weak var imageSrFullView: UIImageView!
    @IBOutlet weak var lblSrAutFull: UILabel!
    @IBOutlet weak var lblSrIstFull: UILabel!
    
    
    @IBOutlet weak var infLbl: UILabel!
    @IBOutlet weak var infoLbl: UILabel!
    
    
    @IBOutlet weak var newTrendLbl: UILabel!
}
