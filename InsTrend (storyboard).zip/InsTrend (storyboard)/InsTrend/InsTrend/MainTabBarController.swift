//
//  MainTabBarController.swift
//  InsTrend
//
//  Created by mac on 30.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .gray
        
        viewControllers = []
    }
}
