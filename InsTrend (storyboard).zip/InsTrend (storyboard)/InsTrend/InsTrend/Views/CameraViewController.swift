//
//  CameraViewController.swift
//  InsTrend
//
//  Created by mac on 28.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CameraViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
