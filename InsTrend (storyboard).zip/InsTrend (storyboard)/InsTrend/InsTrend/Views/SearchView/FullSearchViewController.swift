//
//  FullSearchViewController.swift
//  InsTrend
//
//  Created by mac on 27.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FullSearchViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate, UISearchResultsUpdating {

    @IBOutlet weak var collectionView: UICollectionView!
    @IBAction func close(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    var searchResult: [Search] = []
    var sear = [Search]()
    
    var searchController: UISearchController!
    
    let countCells = 1
    
    var indexPath:IndexPath!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Поиск вдохновления"
        navigationItem.searchController = searchController
        definesPresentationContext = true

        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.reloadData()
      //  collectionView.layer.cornerRadius = 15.0
        
        
        collectionView.performBatchUpdates(nil) { (return) in
            self.collectionView.scrollToItem(at: self.indexPath, at: .centeredHorizontally, animated: false)
        }
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text {
            self.filterContent(searchText: searchText)
            self.collectionView.reloadData()
        }
    }

    func filterContent(searchText: String) {
        searchResult = sear.filter({ (seac: Search) -> Bool in
            let nameMatch = seac.name.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            let authorMatch = seac.author.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)

            return nameMatch != nil || authorMatch != nil
        })
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searchController.isActive {
            return searchResult.count
        } else {
            return sear.count
        }
    }
    
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "fullSearchCell", for: indexPath) as!
            CustomCollectionViewCell
            
            let resultSr = (searchController.isActive) ? searchResult[indexPath.row] : sear[indexPath.row]
            
            cell.imageSrFullView.contentMode = .scaleToFill
            
            //let defaultLink = "https://lyutikovpavel.github.io/Trend.json"
            let completeLink = resultSr.imgUrl
            
            cell.imageSrFullView.downloadedFrom(link: completeLink)
            cell.imageSrFullView.clipsToBounds = true
            
            cell.lblSrAutFull.text = sear[indexPath.row].author
            cell.lblSrIstFull.text = sear[indexPath.row].istok
            
            return cell
        }

    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let frameCV = collectionView.frame
        
        let widthCell = frameCV.width / CGFloat(countCells)
        let heightCell = widthCell + 70
        
        return CGSize(width: widthCell, height: heightCell)
    }
    
}
