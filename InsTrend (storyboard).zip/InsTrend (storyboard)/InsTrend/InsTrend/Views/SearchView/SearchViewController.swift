//
//  SearchViewController.swift
//  InsTrend
//
//  Created by mac on 27.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

struct Search: Decodable {
    var id: Int
    var name: String
    var author: String
    var imgUrl: String
    var istok : String
}

class SearchViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate, UISearchResultsUpdating {

    let countCells = 3

    var searchResult: [Search] = []
    var sear = [Search]()
    
    var searchController: UISearchController!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        collectionView.dataSource = self
        collectionView.delegate = self
        
        setupSearch()
        network()
    }
    
    private func setupSearch() {
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        searchController.searchBar.placeholder = "Поиск вдохновления"
        navigationItem.searchController = searchController
        definesPresentationContext = true
    }
    
    private func network() {
        let url = URL(string: "https://lyutikovpavel.github.io/search.json")
                  URLSession.shared.dataTask(with: url!) { (data, response, error) in
                  if error == nil {
                           do {
                  self.sear = try JSONDecoder().decode([Search].self, from: data!)
                      } catch {
                  print("Parse Error")
                      }
                  DispatchQueue.main.async {
                  self.collectionView.reloadData()
              }
          }
      }.resume()
    }
    
//tab fullScren
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FullSearchViewController") as! FullSearchViewController
        
        vc.sear = sear
        vc.searchResult = searchResult
//        vc.searchController = searchController
//        vc.searchController.isActive = searchController.isActive
        vc.indexPath = indexPath
        self.navigationController?.present(vc, animated: true, completion: nil)
    }
//tab fullScren
    
//Search
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text {
            self.filterContent(searchText: searchText)
            self.collectionView.reloadData()
        }
//            timer?.invalidate()
//            timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: false, block: { (_) in
//            })
    }

    func filterContent(searchText: String) {
        searchResult = sear.filter({ (seac: Search) -> Bool in
            let nameMatch = seac.name.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
            let authorMatch = seac.author.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)

            return nameMatch != nil || authorMatch != nil
        })
    }
// Search

// CollectionCell
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searchController.isActive {
            return searchResult.count
        } else {
            return sear.count
        }
    }
    
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "searchCell", for: indexPath) as!
            CustomCollectionViewCell
            
            let resultSr = (searchController.isActive) ? searchResult[indexPath.row] : sear[indexPath.row]
            
            cell.imageSrView.contentMode = .scaleToFill
            
            //let defaultLink = "https://lyutikovpavel.github.io/Trend.json"
            let completeLink = resultSr.imgUrl
            
            cell.imageSrView.downloadedFrom(link: completeLink)
            cell.imageSrView.clipsToBounds = true
            
            return cell
        }
    
       func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let frameCV = collectionView.frame
        
        let widthCell = frameCV.width / CGFloat(countCells)
        let heightCell = widthCell
        
        return CGSize(width: widthCell, height: heightCell)
    }
    
}
