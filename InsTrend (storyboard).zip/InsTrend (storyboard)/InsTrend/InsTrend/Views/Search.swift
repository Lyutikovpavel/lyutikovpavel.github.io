//
//  Search.swift
//  InsTrend
//
//  Created by mac on 22.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation
import UIKit

class ViewController: UIViewController {
    
    let searchController = UISearchController(searchResultController: nil)
    
}


