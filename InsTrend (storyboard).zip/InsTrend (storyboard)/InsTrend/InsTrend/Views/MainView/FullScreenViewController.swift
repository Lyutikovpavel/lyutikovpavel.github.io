//
//  FullScreenViewController.swift
//  InsTrend
//
//  Created by mac on 20.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FullScreenViewController: UIViewController {
    
    let customCollectionViewCell = CustomCollectionViewCell()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBAction func close(_ sender: Any) {
    dismiss(animated: true, completion: nil)
    }

    var trends = [Trend]()

    let countCells = 1
    
    var indexPath:IndexPath!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        self.scrollView.delegate = self
//        self.scrollView.minimumZoomScale = 1.0
//        self.scrollView.maximumZoomScale = 3.5
        
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.reloadData()
       // collectionView.layer.cornerRadius = 15.0
        
        collectionView.performBatchUpdates(nil) { (return) in
            self.collectionView.scrollToItem(at: self.indexPath, at: .centeredHorizontally, animated: false)
        }
    }

}

extension FullScreenViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return trends.count
        }
    
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "fullCell", for: indexPath) as!
            CustomCollectionViewCell
            
            //cell.imageFull.contentMode = .scaleToFill
            
    //      let defaultLink = "https://lyutikovpavel.github.io/Trend.json"
            let completeLink = trends[indexPath.row].imageUrl
            
            cell.imageFull.downloadedFrom(link: completeLink)
            cell.imageFull.clipsToBounds = true
            
            cell.lblIstFull.text = trends[indexPath.row].istok
            cell.lblAutFull.text = trends[indexPath.row].author
            

            return cell
        }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let frameCV = collectionView.frame
        
        let widthCell = frameCV.width / CGFloat(countCells)
        let heightCell = widthCell + 70
        
        return CGSize(width: widthCell, height: heightCell)
    }
}
