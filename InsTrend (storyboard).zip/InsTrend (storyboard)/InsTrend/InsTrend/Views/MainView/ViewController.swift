//
//  ViewController.swift
//  InsTrend
//
//  Created by mac on 17.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//
import UIKit

struct Trend: Decodable {
    var id : Int
    var author : String
    var imageUrl : String
    var istok : String
}

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    let countCells = 3
    
    var trends = [Trend]()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        collectionView.delegate = self
        
        network()
    }
// MARK: - JSON
    private func network() {
        let url = URL(string: "https://lyutikovpavel.github.io/Trend.json")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            if error == nil {
                do {
                    self.trends = try JSONDecoder().decode([Trend].self, from: data!)
                } catch {
                    print("Parse Error")
                }
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            }
        }.resume()
    }
}
// MARK: - Collection Cell
extension ViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UIScrollViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return trends.count
        }
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as!
            CustomCollectionViewCell
            
            cell.imageView.contentMode = .scaleToFill
            //let defaultLink = "https://lyutikovpavel.github.io/Trend.json"
            let completeLink = trends[indexPath.row].imageUrl
            cell.imageView.downloadedFrom(link: completeLink)
            cell.imageView.clipsToBounds = true
            
            return cell 
        }
// MARK: - Size
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let frameCV = collectionView.frame
        
        let widthCell = frameCV.width / CGFloat(countCells)
        let heightCell = widthCell 
        
        return CGSize(width: widthCell, height: heightCell)
    }
// MARK: - Push FullScreen
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = storyboard?.instantiateViewController(withIdentifier: "FullScreenViewController") as! FullScreenViewController
        
        vc.trends = trends
        vc.indexPath = indexPath
    
        self.navigationController?.present(vc, animated: true, completion: nil)
        }
}
// MARK: - UIImage Download
 extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        self.image = nil
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.startAnimating()
        activity.color = .gray
        self.addSubview(activity)
        activity.center = self.center
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }

            DispatchQueue.main.async() { [weak self] in
                self?.image = image
                activity.removeFromSuperview()
            }
        }.resume()
    }
    func downloadedFrom(link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
            downloadedFrom(url: url, contentMode: mode)
    }
}
// MARK: - Camera
//Camera
//    @IBAction func takePhoto(_ sender: Any) {
//        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
//            let imagePicker = UIImagePickerController()
//            imagePicker.delegate = self
//            imagePicker.sourceType = UIImagePickerController.SourceType.camera
//            imagePicker.allowsEditing = false
//            self.present(imagePicker, animated: true, completion: nil)
//    }
//}
//Camera
