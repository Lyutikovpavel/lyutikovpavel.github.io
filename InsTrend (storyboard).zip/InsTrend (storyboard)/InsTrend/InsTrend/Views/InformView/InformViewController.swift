//
//  InformViewController.swift
//  InsTrend
//
//  Created by mac on 06.03.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class InformViewController: UIViewController {

    @IBOutlet weak var informLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        informLbl.text = "Мы хотим предложить Вам идею для создания фотографии. Мы отбираем лучшие фотографии каждые три дня и Вы можете увидеть их у нас в приложении. Помимо этого Вам доступен архив ранее отобранных фотографии распологавшихся в Trende. Черпайте вдохнавление у нас и будте в Trende! Все самое свежее, в Trende."
    }


}
