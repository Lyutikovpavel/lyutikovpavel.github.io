//
//  CustCollectionViewCell.swift
//  InsTrend
//
//  Created by mac on 07.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CustCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
