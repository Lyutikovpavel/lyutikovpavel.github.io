//
//  InfoCollectionViewCell.swift
//  InsTrend
//
//  Created by mac on 26.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class InfoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var infoLbl: UILabel!
    
}
