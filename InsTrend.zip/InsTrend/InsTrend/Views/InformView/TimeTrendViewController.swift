//
//  TimeTrendViewController.swift
//  InsTrend
//
//  Created by mac on 06.03.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

struct TimeTrend: Decodable {
    var time : String
}

class TimeTrendViewController: UIViewController,UICollectionViewDataSource {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var timeNew = [TimeTrend]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        
        let url = URL(string: "https://lyutikovpavel.github.io/time.json")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            
            if error == nil {
                
                do {
                    self.timeNew
                        = try JSONDecoder().decode([TimeTrend].self, from: data!)
                } catch {
                    print("Parse Error")
                }
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            }
            
        }.resume()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return timeNew.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "newTrendCell", for: indexPath) as!
        CustomCollectionViewCell

        
        cell.newTrendLbl.text = timeNew[indexPath.row].time
        
        return cell
    }
}
