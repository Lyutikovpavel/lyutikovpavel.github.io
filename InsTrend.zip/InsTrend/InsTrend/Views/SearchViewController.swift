//
//  SearchViewController.swift
//  InsTrend
//
//  Created by mac on 27.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SearchViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}


