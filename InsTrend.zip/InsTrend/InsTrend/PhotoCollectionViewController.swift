//
//  PhotoCollectionViewController.swift
//  InsTrend
//
//  Created by mac on 30.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PhotoCollectionViewController: UICollectionViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.backgroundColor = .orange 
    }
}
