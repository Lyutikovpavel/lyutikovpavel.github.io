//
//  CustomCollectionViewCell.swift
//  InsTrend
//
//  Created by mac on 07.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imageSrView: UIImageView!

       @IBOutlet weak var infLbl: UILabel!
       
       @IBOutlet weak var infoLbl: UILabel!
    
       @IBOutlet weak var imageView: UIImageView!
       
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
