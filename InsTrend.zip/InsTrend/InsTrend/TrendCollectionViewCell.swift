//
//  TrendCollectionViewCell.swift
//  InsTrend
//
//  Created by mac on 07.02.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TrendCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
