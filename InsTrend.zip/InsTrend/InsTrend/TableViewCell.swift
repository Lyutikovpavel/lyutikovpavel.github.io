//
//  TableViewCell.swift
//  InsTrend
//
//  Created by mac on 27.01.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var infoLbl: UILabel!
    
}
