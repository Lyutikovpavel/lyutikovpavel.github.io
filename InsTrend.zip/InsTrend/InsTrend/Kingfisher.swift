//
//  Kingfisher.swift
//  InsTrend
//
//  Created by mac on 18.03.2020.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Kingfisher: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
